HOW TO RUN THE MODEL:

1) Open and Run Docker


2) Open the Command Prompt and change directory until you are in the docker_SMT folder.


3) Execute the command: docker build -t main_test .


4) Execute the command:  docker run -ti main_test

When the program is running it requires two integer input, an instance number (from 1 to 21) and a configuration number (from 1 to 8).
Configurations:
	= 1 -> Default Model minimizing the 1° objective function
	= 2 -> Model with implied constraints minimizing the 1° objective function
	= 3 -> Model with symmetry breaking constraint minimizing the 1° objective function
	= 4 -> Model with implied and symmetry breaking constraints minimizing the 1° objective function
	= 5 -> Second Model minimizing the 2° objective function
	= 6 -> Model with implied constraints minimizing the 2° objective function
	= 7 -> Model with symmetry breaking constraint minimizing the 2° objective function
	= 8 -> Model with implied and symmetry breaking constraints minimizing the 2° objective function
